$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "9"
$LUT = "30"
$FF = "27"
$DSP = "1"
$BRAM ="0"
$SRL ="0"
#=== Final timing ===
$TargetCP = "8.000"
$CP = "3.704"
